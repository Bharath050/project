package com.example.eduLoan.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.eduLoan.Models.UserModel;
import com.example.eduLoan.Repositories.UserRepo;
@Service
public class UserService {
	@Autowired
	UserRepo ur;

	public UserModel userInserValues(UserModel e) {
		return ur.save(e);
	}

	public Optional<UserModel> userGetValue(int id) {
		return ur.findById(id);
	}

	public UserModel userPutMethod(UserModel x) {
		return ur.save(x);
	}

	public String userDeleteById(int id) {
		ur.deleteById(id);
		return id+" Deleted !!";
	}

	public List<UserModel> getUserDetails() {
		return ur.findAll();
	}


	
	
}
