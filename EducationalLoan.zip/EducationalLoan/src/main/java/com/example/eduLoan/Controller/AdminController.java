package com.example.eduLoan.Controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.example.eduLoan.Models.UserModel;
import com.example.eduLoan.Service.UserService;
@RestController
public class AdminController {
	@Autowired
	UserService us;
	@GetMapping("/viewloan")
	public List<UserModel> getMethod()
	{
		return us.getUserDetails();
	}
	@PostMapping("/upst")
	public UserModel userPostMethod(@RequestBody UserModel e)
	{
		return us.userInserValues(e);
	}
	@GetMapping("/uget/{id}")
	public Optional <UserModel> userGetId(@PathVariable int id)
	{
		return us.userGetValue(id);
	}
	@PutMapping("/uput")
	public UserModel userUpdate(@RequestBody UserModel x)
	{
		return us.userPutMethod(x);
	}
	@DeleteMapping("/udel/{id}")
	public String userDelete(@PathVariable int id)
	{
		return us.userDeleteById(id);
	}
	
}
