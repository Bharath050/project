package com.example.eduLoan.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.eduLoan.Models.LoanApplicationModel;
import com.example.eduLoan.Repositories.LoanRepo;


@Service
public class LoanService {
	@Autowired
	LoanRepo lr;

	public LoanApplicationModel inserValues(LoanApplicationModel e) {
		return lr.save(e);
	}

	public Optional <LoanApplicationModel> getValue(int id)	{
		return lr.findById(id);
	}

	public LoanApplicationModel putMethod(LoanApplicationModel x) {
		return lr.save(x);
	}

	public String deleteById(int id) {
		 lr.deleteById(id);
		 return id+"deleted!!";
	}

	public List<LoanApplicationModel> printMethod() {
		return lr.findAll();
	}
	
}
