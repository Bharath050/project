package com.example.eduLoan.Controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.eduLoan.Models.LoanApplicationModel;
import com.example.eduLoan.Service.LoanService;

@RestController
//@CrossOrigin
public class LoanController {
	@Autowired
	LoanService sc;
	@PostMapping("/pst")
	public LoanApplicationModel PostMethod(@RequestBody LoanApplicationModel e)
	{
		return sc.inserValues(e);
	}
	@GetMapping("/get/{id}")
	public Optional <LoanApplicationModel> getId(@PathVariable int id)
	{
		return sc.getValue(id);
	}
	@PutMapping("/put")
	public LoanApplicationModel update(@RequestBody LoanApplicationModel x)
	{
		return sc.putMethod(x);
	}
	@DeleteMapping("/del/{id}")
	public String delete(@PathVariable int id)
	{
		return sc.deleteById(id);
	}
	@GetMapping("/grt")
	public List<LoanApplicationModel> detailPage()
	{
		return sc.printMethod();
	}
}
