package com.example.eduLoan.Models;

import jakarta.persistence.Id;

public class LoginModel {
	@Id
	private String Email;
	private String Password;
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	
	public String getPassword() {
		return Password;
	}
	public void setPassword(String password) {
		Password = password;
	}
	@Override
	public String toString() {
		return "LoginModel [Email=" + Email + ", password=" + "]";
	}
}
