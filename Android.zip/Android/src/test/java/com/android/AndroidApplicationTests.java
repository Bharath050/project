package com.android;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AndroidApplicationTests {

	@Test
	void contextLoads() {
	}

}
