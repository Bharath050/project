package com.android.Service;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.android.Repository.AndroidRepository;
import com.android.demo.demoClass;

@Service
public class AndroidService {
	@Autowired
	AndroidRepository Arepo;
	public List <demoClass>getservice()
	{
		return Arepo.findAll();
	}
	public Optional<demoClass> getbyId(int id) {
		return Arepo.findById(id);
	}
	public demoClass add(demoClass x) {
		return Arepo.save(x);
	}
	public demoClass edit(demoClass y) {
		return Arepo.save(y);
	}
	public String delete(int id) {
		Arepo.deleteById(id);
		return id+" deleted !!";
	}
}

