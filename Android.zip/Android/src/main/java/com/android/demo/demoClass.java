package com.android.demo;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="moblie")
public class demoClass {
	@Id
	private int id;
	private String model;
	private String RAM;
	private String ROM;
	private int cost;
	private int battery;
	private float display;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public String getRAM() {
		return RAM;
	}
	public void setRAM(String rAM) {
		RAM = rAM;
	}
	public String getROM() {
		return ROM;
	}
	public void setROM(String rOM) {
		ROM = rOM;
	}
	public int getCost() {
		return cost;
	}
	public void setCost(int cost) {
		this.cost = cost;
	}
	public int getBattery() {
		return battery;
	}
	public void setBattery(int battery) {
		this.battery = battery;
	}
	public float getDisplay() {
		return display;
	}
	public void setDisplay(float display) {
		this.display = display;
	}
	@Override
	public String toString() {
		return "demoClass [id=" + id + ", model=" + model + ", RAM=" + RAM + ", ROM=" + ROM + ", cost=" + cost
				+ ", battery=" + battery + ", display=" + display + "]";
	}
}
                     