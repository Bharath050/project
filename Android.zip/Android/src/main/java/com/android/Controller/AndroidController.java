package com.android.Controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.android.Service.AndroidService;
import com.android.demo.demoClass;

@RestController
public class AndroidController {
	@Autowired
	AndroidService Aservice;
	@GetMapping("/get")
	public List<demoClass>read()
	{
		return Aservice.getservice();
	}
	@GetMapping("/byid/{id}")
	public Optional<demoClass> readbyId(@PathVariable int id)
	{
		return Aservice.getbyId(id);
	}
	@PostMapping("/post")
	public demoClass create(@RequestBody demoClass x) {
		return Aservice.add(x);
	}
	@PutMapping("/put")
	public demoClass edit(@RequestBody demoClass y) {
		return Aservice.edit(y);
	}
	@DeleteMapping("/del/{id}")
	public String delete(@PathVariable int id) {
		return Aservice.delete(id);
	}
}
