package com.Insta.demo.comtroller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class InstagramClass {
	@GetMapping("/start")
	public String InstaMethod(@RequestParam String name)
	{
		return "Name = "+name;
	}
	@GetMapping("startnew")
	public String TwoParameter(@RequestParam String username,@RequestParam String password)
	{
		if(username.equals("Bharat")&&password.equals("nn"))
		{
			return "success";
		}
		else
		{
			return "failed";
		}
	}
}
